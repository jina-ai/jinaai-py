
def decide():
    raise Exception("rationale not implemented")

def optimize():
    raise Exception("promptperfect not implemented")

def describe():
    raise Exception("scenex not implemented")

def generate():
    raise Exception("chatcat not implemented")

def generate_image():
    raise Exception("banner implemented")

def configure():
    print('configure not implemented')
