from setuptools import setup, find_packages

setup(
    name='jinaai',
    version='0.1.0',
    author='Jina AI',
    author_email='guillaume.roncari@jina.ai',
    description='Jina AI Python SDK',
    url='https://github.com/jina-ai/jinaai-py.git',
    packages=find_packages(),
    install_requires=[],
)
